﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


enum E_MonsterState
{
    Normal,
    Attack,
   
   
}

public class MonsterSetting : MonoBehaviour
{
    MonsterController MonsterController;
    E_MonsterState MonsterState;
    Launch MonsterLaunch;


    public float fieldOfViewAngle = 3f;
    public float viewDistance = 100;
    public string targetName = "Player";
    

   
    
    public float walkSpeed = 0;
    private float moveSpeed;
    private float runSpeed = 0.5f;

    public GameObject target;

    public bool canAttack = false;

    public void Awake()
    {
        MonsterController = GetComponent<MonsterController>();
    }

    public bool CanSeeTarget()
    {
        var direction = target.transform.position - transform.position;
        direction.y = 0;
        var angle = Vector3.Angle(direction, transform.forward);

        if (MonsterState == E_MonsterState.Normal)
            return false;

        else if (direction.magnitude < viewDistance && angle < fieldOfViewAngle * 0.5f )
        {
            return true;
        }

        else
        {
            moveSpeed = walkSpeed;
            
            return false;
        }
    }


    private void OnTriggerStay(Collider other)
    {
        Debug.Log(other.gameObject.name);
        target = GameObject.Find(targetName);
        RotateToward(target.transform);
        moveSpeed = walkSpeed;
        MonsterState = E_MonsterState.Attack; 


    }

    private void OnTriggerExit(Collider other)
    {
        MonsterState = E_MonsterState.Normal;
        target = null; 
        
        Debug.Log(MonsterLaunch.isAttack);

        
    }
   

    public bool CanAttack()
    {
        if (MonsterState == E_MonsterState.Attack && canAttack == true )
        {
            MonsterLaunch = GetComponentInChildren<Launch>();
            MonsterLaunch.isAttack = true;
            return true;
        }
           
        else if(canAttack == false || MonsterState != E_MonsterState.Attack|| MonsterState == E_MonsterState.Normal )
        {
            MonsterLaunch = GetComponentInChildren<Launch>();
            MonsterLaunch.isAttack = false;
            return false;
        }
        else
        {
            return false;
        }
    }
   
    public bool CanMove()
    {
        if (MonsterState == E_MonsterState.Normal)
            return true;
        else if (MonsterState != E_MonsterState.Attack)
            return false;
        else
            return false; 
            
    }

    public void Idle()
    {
        MonsterState = E_MonsterState.Normal;
        moveSpeed = walkSpeed;
        transform.position += transform.forward * moveSpeed * Time.deltaTime;

    }

    public void Attack()
    {
        
        MonsterState = E_MonsterState.Attack;
       
        moveSpeed = runSpeed;
        
        Debug.Log(MonsterLaunch.isAttack);


    }

  
    public void RotateToward(Transform target)
    {
        Vector3 direction = target.transform.position - transform.position;
        Quaternion rotation = Quaternion.LookRotation(direction);
        transform.rotation = rotation;
    }

    private void Start()
    {

        
        MonsterState = E_MonsterState.Normal;
        moveSpeed = walkSpeed;
    }

    private void Update()
    {
        
    }
}
